var performance = {};



var global = {};
var require = function(module) {};
var process = {};
var __dirname = "";

var esprima = { tokenize: {}, parse: {} };
var acorn = { walk: { simple: {} } };

var exports = {};
var define = {};
var module = {};

