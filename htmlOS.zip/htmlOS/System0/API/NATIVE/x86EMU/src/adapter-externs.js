

/** @constructor */
function ScreenAdapter()
{
    this.put_pixel_linear = function() {};
    this.put_pixel_linear32 = function() {};
    this.put_char = function() {};
    this.set_mode = function() {};
    this.set_size_graphical = function() {};
    this.set_size_text = function() {};
    this.update_cursor = function() {};
    this.update_cursor_scanline = function() {};
    this.timer = function() {};
}
