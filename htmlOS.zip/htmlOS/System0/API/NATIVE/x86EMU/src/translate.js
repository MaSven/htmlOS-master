/** @constructor */
function DynamicTranslator(something)
{
    // TODO
    dbg_assert(false);

    this.clear_cache = function() {};
    this.cycle_translated = function() {};
}
