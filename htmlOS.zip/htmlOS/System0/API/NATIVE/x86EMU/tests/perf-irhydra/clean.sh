rm -f code-*.asm hydrogen-*.cfg
